import sqlite3
import cgi, cgitb
form = cgi.FieldStorage()
print("""
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Дела</title>
</head>
<body>
<h2>Для добавления данных в таблицу введите данные в форму</h2>
<form>
	<label>Подсудимый</label><br>
	<select name="id_def">
		<option value="null">--Выберите подсудимого--</option>
	</select><br>
	<label>Судья</label><br>
	<select name="id_judge">
		<option value="null">--Выберите судью--</option>
	</select><br>
	<label>Дата принятия дела</label><br>
	<input type="datetime-local" name="start_date"><br>
	<label>Дата закрытия дела</label><br>
	<input type="datetime-local" name="end_date"><br>
	<label>Подсудимый виновен?</label><br>
	<input type="radio" name="guilty" id="r1" value="true"><br>
	<input type="radio" name="guilty" id="r2" value="false"><br>
	<input type="radio" name="guilty" id="r3" value="null"><br>
	
	<input type="submit" name="submit">
</form><br>
<button type="button" onclick="home()">Вернуться в главное меню</button>
<script type="text/javascript">
	function home(){
		window.location.href = "http://localhost:5555/cgi_bin/";
	}
</script>
</body>
</html>""")
